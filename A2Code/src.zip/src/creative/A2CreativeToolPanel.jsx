import A2ToolPanel from "../components/A2ToolPanel";

export default class A2CreativeToolPanel extends A2ToolPanel{

}