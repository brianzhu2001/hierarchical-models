import A2GraphicsComponent from "../components/A2GraphicsComponent";

export default class A2CreativeComponent extends A2GraphicsComponent{

}